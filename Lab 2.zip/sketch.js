function setup() {
  createCanvas(128, 128);
}

function draw() {
  background(16);
  colorMode(RGB, 255, 255, 255, 1);
  fill (255,0,0,1);
  arc (28,28,48,48,0,2*PI);
  fill (0,255,0,1);
  arc (28,100,48,48,0,2*PI);
  fill (0,0,255,1);
  arc (100,28,48,48,0,2*PI);
  fill (255,255,0,1);
  arc (100,100,48,48,0,2*PI);
  fill (128,128,128,1);
  quad (64,68, 64, 60, 68, 48, 68, 80);
  triangle(64,68,64,60,54,64);
}