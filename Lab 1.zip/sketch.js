function setup() {
  createCanvas(128, 128);
}

function draw() {
  background(25);
  stroke(255);
  line(0, 127, 128, 127);
  
  noStroke();
  fill(255);
  ellipse(32, 30, 55, 55);
  
  fill(127);
  stroke(25);
  rect(0, 64, 32, 64);
  rect(32, 96, 32, 32);
  rect(64, 32, 32, 128, 10);
  rect(96, 64, 32, 64);
  
    stroke(255);
  line(0, 127, 128, 128);
}