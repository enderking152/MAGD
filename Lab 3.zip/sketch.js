let fr = 60;
let r = 10;

function setup() {
  createCanvas(400, 400);
  frameRate(fr);
}

function draw() {
  background(220);
  colorMode(RGB, 255);
  let D = abs(dist(mouseX, mouseY, 200, 200));
  let d = dist (mouseX, mouseY, pmouseX, pmouseY);
  stroke(255,0,0);
  fill (0, 255, 0);
  circle(mouseX, mouseY, D);
  fill (0,0,255);
  circle(pmouseX, pmouseY, d);
}